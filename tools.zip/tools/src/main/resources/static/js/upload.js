const form = document.querySelector("form");
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        const formData = new FormData();
        formData.append('excel_file',document.getElementById('file_picker').files[0]);
        formData.append('name','dsaxen21');
        formData.append('name',document.getElementById('file_picker').files[0].name);
        fetch("http://e2e-cs-prod.hcck8s-ctc.optum.com/upload_excel", {
              mode:'no-cors',
              method:"POST",
              enctype: 'multipart/form-data',
              cache:'no-cache',
              body:formData
        })
          .then((res) => {
            document.getElementById('output').textContent="File is Successfully Uploaded";
            console.log(res);
          })
          .catch((err) => {
            console.log(err);
          });
});