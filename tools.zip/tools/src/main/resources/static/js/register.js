var form=document.getElementById('form')

   form.addEventListener('submit', function(e){
   e.preventDefault()

   var namee=document.getElementById('user-name').value
   var passs=document.getElementById('pass-word').value

      fetch("http://e2e-cs-prod.hcck8s-ctc.optum.com/register", {
               mode:'no-cors',
               method:"POST",
               body:new URLSearchParams({
                name:namee,
                pass:passs
               })
      })

});