var form=document.getElementById('form')
  form.addEventListener('submit', function(e){
  e.preventDefault()

  var namee=document.getElementById('user-name').value
  var passs=document.getElementById('pass-word').value

      fetch("http://e2e-cs-prod.hcck8s-ctc.optum.com/login", {
               mode:'no-cors',
               method:"POST",
               cache:'no-cache',
               body:new URLSearchParams({
                name:namee,
                pass:passs
               })
      })

});

