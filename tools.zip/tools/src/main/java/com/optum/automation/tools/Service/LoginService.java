package com.optum.automation.tools.Service;
//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//


import io.netty.channel.ChannelOption;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;

import java.io.File;
import java.io.IOException;

@Service
public class LoginService {
   // private static final Logger LOGGER = LoggerFactory.getLogger(LoginService.class);
    private final String baseUrl;
    private final Integer port;
    private final WebClient client;

    public LoginService(@Value("${baseUrl}") String url, @Value("${backend.port}") Integer port) {
        this.baseUrl = url;
        this.port = port;
        this.client = this.getWebClient();
    }

    public Mono<String> registerUser(String username, String password) {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap();
        headers.add("name", username);
        headers.add("pass", password);
        return ((RequestBodySpec)((RequestBodySpec)this.client.post().uri("/register", new Object[0])).headers((httpHeaders) -> {
            httpHeaders.addAll(headers);
        })).exchangeToMono((clientResponse) -> {
            return clientResponse.bodyToMono(String.class);
        });
    }

    public Mono<String> loginToApp(String username, String password) {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap();
        headers.add("name", username);
        headers.add("pass", password);
        return ((RequestBodySpec)((RequestBodySpec)this.client.post().uri("/login", new Object[0])).headers((httpHeaders) -> {
            httpHeaders.addAll(headers);
        })).exchangeToMono((clientResponse) -> {
            return clientResponse.bodyToMono(String.class);
        });
    }

    public Mono<String> uploadMemberFile(MultipartFile file) {
        return ((RequestBodySpec)this.client.post().uri("/upload_members", new Object[0])).contentType(MediaType.MULTIPART_FORM_DATA).body(BodyInserters.fromMultipartData(this.fromFile(file))).retrieve().bodyToMono(String.class);
    }


    private MultiValueMap<String, HttpEntity<?>> fromFile(MultipartFile multipartFile) {
        MultipartBodyBuilder builder = new MultipartBodyBuilder();

        try {
            File file = File.createTempFile("targetFile", ".xlsx");
            multipartFile.transferTo(file);
            builder.part("file", new FileSystemResource(file));
        } catch (IOException var4) {
           // LOGGER.error("--- MultipartFile conversion failed, error = {}.", var4.getMessage());
        }

        return builder.build();
    }



    public Flux<DataBuffer> getValidationDataTestLink(String username) {
        return this.client.get().uri("/get_result", new Object[0]).header("user", new String[]{username}).retrieve().bodyToFlux(DataBuffer.class);
    }

    public Mono<String> getFunctionalityStatus(String username) {
        return this.client.get().uri("/dashboard", new Object[0]).header("user", new String[]{username}).retrieve().bodyToMono(String.class);
    }

    @Bean
    private WebClient getWebClient() {
        HttpClient httpClient = HttpClient.create().baseUrl(this.baseUrl).port(this.port).tcpConfiguration((client) -> {
            return client.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 1200000).doOnConnected((conn) -> {
                conn.addHandlerLast(new ReadTimeoutHandler(1200000)).addHandlerLast(new WriteTimeoutHandler(1200000));
            });
        });
        ClientHttpConnector connector = new ReactorClientHttpConnector(httpClient);
        //LOGGER.info("Base url = {}, backend-port to connect to = {}.", this.baseUrl, this.port);
        return WebClient.builder().clientConnector(connector).build();
    }
}
