package com.optum.automation.tools.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.reactive.result.view.RedirectView;

@Controller
public class MainController {
	
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String login() {
		return "index";
	}
	
	@RequestMapping(value="/register", method=RequestMethod.GET)
	public String newuser() {
		System.out.println("here");
		return "newuser";
	}
	
	@RequestMapping(value="/optum", method=RequestMethod.GET)
	public RedirectView optumweb() {
		RedirectView redirectView = new RedirectView();
	    redirectView.setUrl("http://www.optum.com");
	    return redirectView;
	}
	
	@RequestMapping(value="/aboutus", method=RequestMethod.GET)
	public String about() {
		return "about";
	}
	
	@RequestMapping(value="/home", method=RequestMethod.GET)
	public String home() {
		return "home";
	}
	
	@RequestMapping(value="/b&e", method=RequestMethod.GET)
	public String be() {
		return "b&e";
	}
	
	@RequestMapping(value="/b&evalidation", method=RequestMethod.GET)
	public String bevalidation() {
		return "b&evalidation";
	}
	
	@RequestMapping(value="/bundleassembly", method=RequestMethod.GET)
	public String bundleassembly() {
		return "bundleassembly";
	}
	
	@RequestMapping(value="/cirrus", method=RequestMethod.GET)
	public String cirrus() {
		return "cirrus";
	}
	
	@RequestMapping(value="/cirrusmanualclaimentry", method=RequestMethod.GET)
	public String cirrusmanualclaimentry() {
		return "cirrusmanualclaimentry";
	}
	
	@RequestMapping(value="/commisionstatement", method=RequestMethod.GET)
	public String commisionstatement() {
		return "commisionstatement";
	}
	
	@RequestMapping(value="/eobpravalidation", method=RequestMethod.GET)
	public String eobpravalidation() {
		return "eobpravalidation";
	}
	
	@RequestMapping(value="/groupvalidation", method=RequestMethod.GET)
	public String groupvalidation() {
		return "groupvalidation";
	}
	
	@RequestMapping(value="/invoice", method=RequestMethod.GET)
	public String invoice() {
		return "invoice";
	}
	
	@RequestMapping(value="/obm", method=RequestMethod.GET)
	public String obm() {
		return "obm";
	}
	
	@RequestMapping(value="/optumrx", method=RequestMethod.GET)
	public String optumrx() {
		return "optumrx";
	}
	
	@RequestMapping(value="/optumrxvalidation", method=RequestMethod.GET)
	public String optumrxvalidation() {
		return "optumrxvalidation";
	}
	
	@RequestMapping(value="/pcp", method=RequestMethod.GET)
	public String pcp() {
		return "pcp";
	}
	
	@RequestMapping(value="/providernetwork", method=RequestMethod.GET)
	public String providernetwork() {
		return "providernetwork";
	}
	
	@RequestMapping(value="/providerroster", method=RequestMethod.GET)
	public String providerroster() {
		return "providerroster";
	}
	
	@RequestMapping(value="/providersets", method=RequestMethod.GET)
	public String providersets() {
		return "providersets";
	}
	
	@RequestMapping(value="/solaris", method=RequestMethod.GET)
	public String solaris() {
		return "solaris";
	}
	
	@RequestMapping(value="/speciality", method=RequestMethod.GET)
	public String speciality() {
		return "speciality";
	}
	
	
}
