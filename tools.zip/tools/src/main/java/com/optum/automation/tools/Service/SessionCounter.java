package com.optum.automation.tools.Service;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

public class SessionCounter implements HttpSessionListener {
    private static int totalActiveSessions;

    public SessionCounter() {
    }

    public static int getTotalActiveSession() {
        return totalActiveSessions;
    }

    public static void reduceActiveSession() {
        --totalActiveSessions;
    }

    public void sessionCreated(HttpSessionEvent arg0) {
        ++totalActiveSessions;
        arg0.getSession().setMaxInactiveInterval(3000);
    }

    public void sessionDestroyed(HttpSessionEvent arg0) {
        --totalActiveSessions;
    }
}

